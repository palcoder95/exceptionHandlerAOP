package com.example.exceptionhandleraop.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
    @GetMapping("/get")
    public String getEmployee(){
        System.out.println(4/0);
        return "Employee1: abcd";
    }
}
