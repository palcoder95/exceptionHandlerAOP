package com.example.exceptionhandleraop.aop;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;

@RestControllerAdvice
@Slf4j
public class EhAdvice {

    Logger logger = LoggerFactory.getLogger(EhAdvice.class);
    @ExceptionHandler(value= Exception.class)
    public String handleErrors(){
        logger.error(Instant.now()+ ":Error occurred:Arithmetic Exception");
        return "Please contact App Support team";
    }
}
