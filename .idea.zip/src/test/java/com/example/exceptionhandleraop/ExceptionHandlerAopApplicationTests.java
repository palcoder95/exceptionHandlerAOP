package com.example.exceptionhandleraop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionHandlerAopApplicationTests {

    @Test
    void contextLoads() {
    }

}
